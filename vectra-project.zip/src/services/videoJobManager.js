module.exports = { videoJobManager: {} };
