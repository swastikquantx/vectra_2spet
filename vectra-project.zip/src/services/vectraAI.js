module.exports = { vectraAI: {} };
